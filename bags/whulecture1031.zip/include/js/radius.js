/*Բ��for IE6��7��8 use VML */
var css = document.createStyleSheet();
css.addRule("v\\:roundrect","behavior:url(#default#vml);display:inline-block;");
var rect = document.createElement('v,roundrect');
ta.setAttribute(rect,{
	arcsize:"20px",
	stroked:false
});
rect.css({width:"20px",height:"20px", antialias:true});
/* Բ��for ie6,7,8 use vml*/
var css= document.createStyleSheet();
css.addRule("v\\:roundrect", "behavior: url(#default#VML);display:inline-block;");
var rect= document.createElement('v:roundrect');
setAttribute(rect, {
arcsize:"20px",
stroked:false
});
rect.css({
width:"20px",height:"20px", antialias:true
});